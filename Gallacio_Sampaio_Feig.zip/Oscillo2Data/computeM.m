function M = computeM(A,B,C,D, Width, Height)

%{
computeM.m

© Leo Gallacio, Fabio Feig

29.12.2024

Calcule la matrice de transformation M

Entree :
    A : corner 1 trie
    B : corner 2 trie
    C : corner 3 trie
    D : corner 4 trie
    Width : x maximum de Corners (largeur)
    Height : y maximum de Corners (hauteur)
Sortie :
    M : matrice de transformation
%}

% Definition des coordonnes initiaux A0 B0 C0 D0 (deformes)
A0 = A;
B0 = B;
C0 = C;
D0 = D;

% Definition des coordonnes finaux A1 B1 C1 D1 (reformes)
A1 = [0 0];
B1 = [Width 0];
C1 = [Width Height];
D1 = [0 Height];

% Definition matrice A du système Ax=b (calculs detailles dans doc)
% x : vecteur colonne contient les coefficients de M
% b : vecteur colonne contient les A1 B1 C1 D1
A = [
    A0(1) A0(2) 1 0 0 0 -A1(1)*A0(1) -A1(1)*A0(2); 
    0 0 0 A0(1) A0(2) 1 -A1(2)*A0(1) -A1(2)*A0(2);
    B0(1) B0(2) 1 0 0 0 -B1(1)*B0(1) -B1(1)*B0(2); 
    0 0 0 B0(1) B0(2) 1 -B1(2)*B0(1) -B1(2)*B0(2);
    C0(1) C0(2) 1 0 0 0 -C1(1)*C0(1) -C1(1)*C0(2); 
    0 0 0 C0(1) C0(2) 1 -C1(2)*C0(1) -C1(2)*C0(2);
    D0(1) D0(2) 1 0 0 0 -D1(1)*D0(1) -D1(1)*D0(2); 
    0 0 0 D0(1) D0(2) 1 -D1(2)*D0(1) -D1(2)*D0(2);
    ];

% Definition du vecteur b = coordonnes finaux (reformes)
b = [A1 B1 C1 D1];

% Calcul du vecteur x = coeff de la matrice M
x = A\b';

% Construction de la matrice de transformation M à partir de x
M = [x' 1];
M = reshape(M, 3, 3)';

end