function [Width, Height, A,B,C,D] = orderCorners(Corners)

%{
orderCorners.m

© Leo Gallacio, Fabio Feig

29.12.2024

Tri les corners dans le sens trigonometrique

Entrée :
    Corners = [x1 y1; x2 y2; x3 y3; x4 y4]
Sortie :
    Width : x maximum de Corners (largeur)
    Height : y maximum de Corners (hauteur)
    A : corner le plus proche de l'origine
    B : corner 2 trie
    C : corner 3 trie
    D : corner 4 trie

%}

% Definition des dimensions Width & Height
Width = max(Corners(:, 1));
Height = max(Corners(:, 2));

%Calcul distance Corners-Origine (en bas e gauche)
distances = zeros(1, 4);
for n = 1:4
    distances(n) = sqrt(Corners(n, 1)^2 + Corners(n, 2)^2); % distance euclidienne
end

% Assigne le point le plus proche de (0,0) au corner A
idxA = find(distances == min(distances)); % index du corner avec la plus petite distance
Tmp = Corners(1,:);                       % stockage corner 1 dans variable temporaire
Corners(1,:) = Corners(idxA, :);          % echange corner 1 avec corner dont distance est la plus faible
Corners(idxA, :) = Tmp;                   % echange avec corner 1

xA = Corners(1, 1); % definition abscisse corner A
yA = Corners(1, 2); % definition ordonnee corner A

% Calcul des angles formes par chaque Corners avec A
angleB = atan2((Corners(2, 2)-yA), (Corners(2, 1)-xA));
angleC = atan2((Corners(3, 2)-yA), (Corners(3, 1)-xA));
angleD = atan2((Corners(4, 2)-yA), (Corners(4, 1)-xA));

% Tri des lignes
Corners = [               % redefinition de Corners 
    angleB Corners(2, :); % ajout des angles
    angleC Corners(3, :); % en 1ere colonne
    angleD Corners(4, :); % pour utiliser sortrows
    ];

Corners = sortrows(Corners); % tri

% Rearrangement de Corners
Corners(:,1) = [];

% Version triee de Corners
Corners = [
    xA yA;
    Corners(1, :);
    Corners(2, :);
    Corners(3, :);
    ];

% Valeurs retournees
A = Corners( 1, :);
B = Corners( 2, :);
C = Corners( 3, :);
D = Corners( 4, :);

end
