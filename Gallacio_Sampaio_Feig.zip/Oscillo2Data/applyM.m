function W = applyM(M, C)

%{
applyM.m

© Leo Gallacio, Fabio Feig

29.12.2024

Applique la matrice de transformation M

Entree :
    M : matrice de transformation
    C : vecteur contenant les coordonnees des traces reformees
Sortie :
    W : vecteur contenant les coordoonees des traces reformees
%}


% Stockage des coordonnees XY dans U
U = [C(:,1) C(:,2)];

% Ajout d'une 3e colonne de 1 (passage coordonnees homogenes)
U(:,3)=1;

% Produit matrice-vecteur de M et U'
V = M*U';

% Transposition de V
V = V';

% Conversion coordonnees homogenes vers cartesiens (diviser x et y par z)
W = [V(:,1)./V(:,3) V(:,2)./V(:,3)];

end